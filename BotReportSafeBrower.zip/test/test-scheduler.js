const ConfigManager = require('../src/services/ConfigManager');
const DatabaseManager = require('../src/services/DatabaseManager');
const SchedulerService = require('../src/services/SchedulerService');
const ReportController = require('../src/controllers/ReportController');
const logger = require('../src/utils/logger');

async function testScheduler() {
  console.log('🧪 Testing Scheduler Service\n');
  
  try {
    // Initialize ConfigManager
    await ConfigManager.initialize();
    console.log('✅ ConfigManager initialized');
    
    // Get database
    const db = ConfigManager.getDatabase();
    console.log('✅ Database connected');
    
    // Initialize ReportController (mock)
    const reportController = {
      reportUrl: async (url, options) => {
        console.log(`  📸 Mock reporting URL: ${url}`);
        return {
          success: true,
          screenshotPath: './test-screenshot.png',
          error: null
        };
      }
    };
    
    // Initialize SchedulerService
    const scheduler = new SchedulerService(db, reportController);
    await scheduler.initialize();
    console.log('✅ SchedulerService initialized');
    
    // Check status
    const status = scheduler.getStatus();
    console.log(`\n📊 Scheduler Status:`);
    console.log(`   Running: ${status.isRunning}`);
    console.log(`   Active Jobs: ${status.activeJobs}`);
    
    // Add a test scheduled report (every 0.01 hours = 36 seconds for testing)
    console.log('\n📝 Adding test scheduled report...');
    const reportId = await scheduler.addScheduledReport(
      'https://test-phishing-site.com',
      '5219633203', // Admin user ID
      0.01 // Every 36 seconds for testing
    );
    console.log(`✅ Added scheduled report with ID: ${reportId}`);
    
    // Get scheduled reports
    const reports = await scheduler.getScheduledReports('5219633203');
    console.log(`\n📋 User has ${reports.length} scheduled reports`);
    
    if (reports.length > 0) {
      const report = reports[0];
      console.log(`\n📌 Report Details:`);
      console.log(`   URL: ${report.url}`);
      console.log(`   Interval: ${report.interval_hours} hours`);
      console.log(`   Run Count: ${report.run_count || 0}`);
      console.log(`   Created: ${report.created_at}`);
    }
    
    // Wait for scheduled report to run
    console.log('\n⏳ Waiting for scheduled report to run (40 seconds)...');
    await new Promise(resolve => setTimeout(resolve, 40000));
    
    // Check if report ran
    const updatedReports = await scheduler.getScheduledReports('5219633203');
    if (updatedReports.length > 0) {
      const updatedReport = updatedReports[0];
      console.log(`\n✅ Report Run Count: ${updatedReport.run_count || 0}`);
      console.log(`   Last Run: ${updatedReport.last_run || 'Not yet'}`);
    }
    
    // Stop the scheduled report
    console.log('\n🛑 Stopping scheduled report...');
    const stopped = await scheduler.stopScheduledReportByUrl('https://test-phishing-site.com', '5219633203');
    console.log(stopped ? '✅ Report stopped' : '❌ Failed to stop report');
    
    // Shutdown scheduler
    await scheduler.shutdown();
    console.log('✅ Scheduler shutdown complete');
    
    // Close database
    await db.close();
    console.log('✅ Database closed');
    
    console.log('\n✅ All tests completed successfully!');
    
  } catch (error) {
    console.error('❌ Test failed:', error);
    process.exit(1);
  }
}

// Run the test
testScheduler().catch(console.error);
