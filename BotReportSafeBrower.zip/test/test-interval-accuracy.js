const ConfigManager = require('../src/services/ConfigManager');
const DatabaseManager = require('../src/services/DatabaseManager');
const SchedulerService = require('../src/services/SchedulerService');
const logger = require('../src/utils/logger');

async function testIntervalAccuracy() {
  console.log('🧪 Testing Scheduler Interval Accuracy\n');
  console.log('This test will verify that reports run at exact intervals.');
  console.log('Testing with 0.1 hour interval (6 minutes)\n');
  
  const executionTimes = [];
  let reportId;
  let scheduler;
  let db;
  
  try {
    // Initialize ConfigManager
    await ConfigManager.initialize();
    db = ConfigManager.getDatabase();
    
    // Mock ReportController that logs execution times
    const reportController = {
      reportUrl: async (url, options) => {
        const now = new Date();
        executionTimes.push(now);
        console.log(`✅ Report executed at: ${now.toLocaleTimeString()}.${now.getMilliseconds()}`);
        
        if (executionTimes.length > 1) {
          const lastTime = executionTimes[executionTimes.length - 2];
          const currentTime = executionTimes[executionTimes.length - 1];
          const diffMs = currentTime - lastTime;
          const diffMinutes = diffMs / 60000;
          console.log(`   Time since last run: ${diffMinutes.toFixed(2)} minutes (${diffMs}ms)`);
          
          // Check accuracy (should be 6 minutes ± 1 second)
          const expectedMs = 6 * 60 * 1000; // 6 minutes
          const tolerance = 1000; // 1 second tolerance
          const isAccurate = Math.abs(diffMs - expectedMs) <= tolerance;
          
          if (isAccurate) {
            console.log(`   ✅ Interval is accurate (within tolerance)`);
          } else {
            console.log(`   ⚠️ Interval deviation: ${Math.abs(diffMs - expectedMs)}ms`);
          }
        }
        
        return {
          success: true,
          screenshotPath: './test.png',
          error: null
        };
      }
    };
    
    // Initialize SchedulerService
    scheduler = new SchedulerService(db, reportController);
    await scheduler.initialize();
    
    // Clean up any existing test reports
    const existingReports = await db.getScheduledReportsByUrl('https://test-interval.com');
    for (const report of existingReports) {
      await db.deactivateScheduledReport(report.id);
    }
    
    // Add test scheduled report with 0.1 hour interval (6 minutes)
    console.log('📝 Creating scheduled report with 0.1 hour interval (6 minutes)...\n');
    reportId = await scheduler.addScheduledReport(
      'https://test-interval.com',
      'test-user-123',
      0.1 // 0.1 hours = 6 minutes
    );
    
    console.log('⏰ Waiting for multiple executions to verify interval accuracy...');
    console.log('   Expected: Report should run every 6 minutes (360 seconds)\n');
    
    // Wait for 20 minutes to see at least 3 executions
    const testDurationMinutes = 20;
    const testDurationMs = testDurationMinutes * 60 * 1000;
    
    await new Promise(resolve => {
      const startTime = Date.now();
      const checkInterval = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const elapsedMinutes = Math.floor(elapsed / 60000);
        const elapsedSeconds = Math.floor((elapsed % 60000) / 1000);
        
        process.stdout.write(`\r⏳ Test running: ${elapsedMinutes}:${elapsedSeconds.toString().padStart(2, '0')} / ${testDurationMinutes}:00`);
        
        if (elapsed >= testDurationMs) {
          clearInterval(checkInterval);
          console.log('\n');
          resolve();
        }
      }, 1000);
    });
    
    // Analyze results
    console.log('\n📊 Test Results:\n');
    console.log(`Total executions: ${executionTimes.length}`);
    console.log(`Expected executions: ${Math.floor(testDurationMinutes / 6) + 1}`);
    
    if (executionTimes.length > 1) {
      const intervals = [];
      for (let i = 1; i < executionTimes.length; i++) {
        const diffMs = executionTimes[i] - executionTimes[i - 1];
        intervals.push(diffMs);
      }
      
      const avgIntervalMs = intervals.reduce((a, b) => a + b, 0) / intervals.length;
      const avgIntervalMinutes = avgIntervalMs / 60000;
      
      console.log(`\nInterval Analysis:`);
      console.log(`  Average interval: ${avgIntervalMinutes.toFixed(2)} minutes`);
      console.log(`  Expected interval: 6.00 minutes`);
      console.log(`  Accuracy: ${((6 / avgIntervalMinutes) * 100).toFixed(1)}%`);
      
      // Check if all intervals are accurate
      const expectedMs = 6 * 60 * 1000;
      const tolerance = 2000; // 2 second tolerance
      const allAccurate = intervals.every(interval => Math.abs(interval - expectedMs) <= tolerance);
      
      if (allAccurate) {
        console.log(`\n✅ SUCCESS: All intervals are within tolerance (±2 seconds)`);
      } else {
        console.log(`\n⚠️ WARNING: Some intervals exceeded tolerance`);
      }
    }
    
  } catch (error) {
    console.error('\n❌ Test failed:', error);
  } finally {
    // Cleanup
    if (scheduler) {
      await scheduler.shutdown();
    }
    if (db && reportId) {
      await db.deactivateScheduledReport(reportId);
    }
    if (db) {
      await db.close();
    }
    console.log('\n🧹 Cleanup complete');
  }
}

// Run the test
testIntervalAccuracy().catch(console.error);
