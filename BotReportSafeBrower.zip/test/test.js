const ReportController = require('../src/controllers/ReportController');
const config = require('../src/config/config');
const logger = require('../src/utils/logger');

async function runTests() {
  logger.info('Starting test suite...');
  
  const controller = new ReportController();
  
  try {
    // Test 1: Initialize controller
    logger.info('Test 1: Initializing controller...');
    await controller.initialize();
    logger.info('✅ Controller initialized successfully');
    
    // Test 2: Report single URL
    logger.info('Test 2: Reporting single URL...');
    const singleResult = await controller.reportUrl(config.report.defaultUrl, {
      targetSite: 'googleSafeBrowsing',
      message: 'Test report from automated system',
      takeScreenshot: true
    });
    logger.info('✅ Single URL reported successfully', singleResult);
    
    // Test 3: Get available targets
    logger.info('Test 3: Getting available targets...');
    const targets = await controller.getAvailableTargets();
    logger.info('✅ Available targets retrieved', targets);
    
    // Test 4: Handle Telegram command (status)
    logger.info('Test 4: Testing Telegram command handling...');
    const statusResult = await controller.handleTelegramCommand('/status', {});
    logger.info('✅ Telegram command handled successfully', statusResult);
    
    logger.info('🎉 All tests completed successfully!');
    
  } catch (error) {
    logger.error('❌ Test failed', error);
  } finally {
    // Cleanup
    await controller.shutdown();
    logger.info('Test cleanup completed');
  }
}

// Run tests if this file is executed directly
if (require.main === module) {
  runTests().catch(error => {
    logger.error('Unhandled test error', error);
    process.exit(1);
  });
}

module.exports = { runTests };
