const ConfigManager = require('../src/services/ConfigManager');
const SchedulerService = require('../src/services/SchedulerService');
const ReportController = require('../src/controllers/ReportController');
const BrowserService = require('../src/services/BrowserService');

async function testRealScheduler() {
  console.log('🔄 Testing Real Scheduler with Actual Reporting\n');
  
  let scheduler, db, browserService;
  
  try {
    // Initialize services
    await ConfigManager.initialize();
    db = ConfigManager.getDatabase();
    
    // Initialize browser service
    browserService = new BrowserService();
    await browserService.initialize();
    
    // Initialize real report controller
    const reportController = new ReportController(browserService);
    
    // Initialize scheduler with real controller
    scheduler = new SchedulerService(db, reportController);
    await scheduler.initialize();
    
    console.log('✅ All services initialized\n');
    
    // Clean up any existing test reports
    const existingReports = await db.getScheduledReportsByUrl('https://d5studio.my.id');
    for (const report of existingReports) {
      await scheduler.stopScheduledReport(report.id);
    }
    
    // Create a scheduled report for 0.1 hours (6 minutes)
    console.log('📝 Creating scheduled report:');
    console.log('   URL: https://d5studio.my.id');
    console.log('   Interval: 0.1 hours (6 minutes)\n');
    
    const reportId = await scheduler.addScheduledReport(
      'https://d5studio.my.id',
      'test-admin',
      0.1
    );
    
    console.log(`✅ Scheduled report created with ID: ${reportId}\n`);
    
    // Get scheduler status
    const status = scheduler.getStatus();
    console.log('📊 Scheduler Status:');
    console.log(`   Running: ${status.isRunning ? 'Yes' : 'No'}`);
    console.log(`   Active Jobs: ${status.activeJobs}\n`);
    
    // Get scheduled reports
    const reports = await scheduler.getScheduledReports();
    console.log('📋 Active Scheduled Reports:');
    for (const report of reports) {
      console.log(`   ID: ${report.id}`);
      console.log(`   URL: ${report.url}`);
      console.log(`   Interval: ${report.interval_hours} hours`);
      console.log(`   Created: ${report.created_at}`);
      console.log(`   Active: ${report.is_active ? 'Yes' : 'No'}\n`);
    }
    
    // Wait 1 minute to see if the first report runs
    console.log('⏳ Waiting 1 minute to observe first execution...\n');
    
    await new Promise(resolve => {
      let seconds = 0;
      const interval = setInterval(() => {
        seconds++;
        process.stdout.write(`\r⏱️ ${seconds} seconds elapsed...`);
        if (seconds >= 60) {
          clearInterval(interval);
          console.log('\n');
          resolve();
        }
      }, 1000);
    });
    
    // Check report history
    const history = await db.getReportHistory('test-admin', 10);
    console.log('\n📜 Report History:');
    if (history.length > 0) {
      for (const entry of history.slice(0, 3)) {
        console.log(`   Time: ${entry.created_at}`);
        console.log(`   URL: ${entry.url}`);
        console.log(`   Success: ${entry.success ? 'Yes' : 'No'}`);
        if (!entry.success && entry.error_message) {
          console.log(`   Error: ${entry.error_message}`);
        }
        console.log('');
      }
    } else {
      console.log('   No reports executed yet\n');
    }
    
    // Stop the scheduled report
    console.log('🛑 Stopping scheduled report...');
    await scheduler.stopScheduledReport(reportId);
    console.log('✅ Report stopped\n');
    
  } catch (error) {
    console.error('❌ Test failed:', error);
  } finally {
    // Cleanup
    console.log('🧹 Cleaning up...');
    
    if (scheduler) {
      await scheduler.shutdown();
    }
    
    if (browserService) {
      await browserService.close();
    }
    
    if (db) {
      await db.close();
    }
    
    console.log('✅ Cleanup complete');
    process.exit(0);
  }
}

// Run the test
testRealScheduler().catch(console.error);
