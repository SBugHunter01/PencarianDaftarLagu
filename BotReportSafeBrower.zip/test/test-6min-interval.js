const ConfigManager = require('../src/services/ConfigManager');
const SchedulerService = require('../src/services/SchedulerService');

async function test6MinuteInterval() {
  console.log('🧪 Testing 0.1 Hour (6 minute) Interval\n');
  
  let executionCount = 0;
  const executionTimes = [];
  
  try {
    await ConfigManager.initialize();
    const db = ConfigManager.getDatabase();
    
    // Clean up any existing test reports
    const existingReports = await db.getScheduledReportsByUrl('https://test-6min.com');
    for (const report of existingReports) {
      await db.deactivateScheduledReport(report.id);
    }
    
    // Mock controller
    const reportController = {
      reportUrl: async (url) => {
        executionCount++;
        const now = new Date();
        executionTimes.push(now);
        
        console.log(`[${executionCount}] Report executed at ${now.toLocaleTimeString()}.${now.getMilliseconds()}`);
        
        if (executionTimes.length > 1) {
          const diffMs = (now - executionTimes[executionTimes.length - 2]);
          const diffSeconds = diffMs / 1000;
          const diffMinutes = diffMs / 60000;
          console.log(`    Time since last: ${diffMinutes.toFixed(2)} minutes (${diffSeconds.toFixed(1)} seconds)`);
          
          // Check accuracy (6 minutes = 360 seconds ± 2 seconds tolerance)
          const expectedSeconds = 360;
          const toleranceSeconds = 2;
          const actualSeconds = diffSeconds;
          const isAccurate = Math.abs(actualSeconds - expectedSeconds) <= toleranceSeconds;
          
          if (isAccurate) {
            console.log(`    ✅ Interval is accurate`);
          } else {
            console.log(`    ⚠️ Interval deviation: ${(actualSeconds - expectedSeconds).toFixed(1)} seconds`);
          }
        }
        
        return { success: true, screenshotPath: 'test.png', error: null };
      }
    };
    
    // Create scheduler
    const scheduler = new SchedulerService(db, reportController);
    await scheduler.initialize();
    
    // Add report with 0.1 hour interval (6 minutes = 360 seconds)
    console.log(`Creating report with interval: 0.1 hours (6 minutes = 360 seconds)\n`);
    
    const reportId = await scheduler.addScheduledReport(
      'https://test-6min.com',
      'test-user',
      0.1  // 0.1 hours = 6 minutes
    );
    
    // Wait for 13 minutes to see 2-3 executions
    const waitMinutes = 13;
    console.log(`Waiting ${waitMinutes} minutes to observe executions...\n`);
    
    const startTime = Date.now();
    await new Promise(resolve => {
      const checkInterval = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const elapsedMinutes = Math.floor(elapsed / 60000);
        const elapsedSeconds = Math.floor((elapsed % 60000) / 1000);
        
        process.stdout.write(`\r⏳ Time elapsed: ${elapsedMinutes}:${elapsedSeconds.toString().padStart(2, '0')} / ${waitMinutes}:00`);
        
        if (elapsed >= waitMinutes * 60000) {
          clearInterval(checkInterval);
          console.log('\n');
          resolve();
        }
      }, 1000);
    });
    
    // Show results
    console.log('\n📊 Test Results:');
    console.log(`Total executions: ${executionCount}`);
    console.log(`Expected: ${Math.floor(waitMinutes / 6) + 1} executions (1 initial + ${Math.floor(waitMinutes / 6)} intervals)`);
    
    if (executionTimes.length > 1) {
      console.log('\nInterval Analysis:');
      const intervals = [];
      for (let i = 1; i < executionTimes.length; i++) {
        const diffMs = executionTimes[i] - executionTimes[i-1];
        const diffMinutes = diffMs / 60000;
        intervals.push(diffMs);
        console.log(`  Interval ${i}: ${diffMinutes.toFixed(2)} minutes`);
      }
      
      const avgMs = intervals.reduce((a,b) => a+b, 0) / intervals.length;
      const avgMinutes = avgMs / 60000;
      const accuracy = (6 / avgMinutes) * 100;
      
      console.log(`\nAverage interval: ${avgMinutes.toFixed(2)} minutes`);
      console.log(`Expected interval: 6.00 minutes`);
      console.log(`Accuracy: ${accuracy.toFixed(1)}%`);
      
      // Check if accurate (within 2% tolerance)
      if (accuracy >= 98 && accuracy <= 102) {
        console.log('\n✅ SUCCESS: Interval timing is accurate!');
      } else {
        console.log('\n⚠️ WARNING: Interval timing needs adjustment');
      }
    }
    
    // Cleanup
    await scheduler.shutdown();
    await db.deactivateScheduledReport(reportId);
    await db.close();
    
    console.log('\n🧹 Test cleanup complete');
    
  } catch (error) {
    console.error('❌ Error:', error);
  }
  
  process.exit(0);
}

test6MinuteInterval();
