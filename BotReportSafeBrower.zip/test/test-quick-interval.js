const ConfigManager = require('../src/services/ConfigManager');
const SchedulerService = require('../src/services/SchedulerService');

async function quickTest() {
  console.log('🚀 Quick Scheduler Test - 10 second intervals\n');
  
  let executionCount = 0;
  const executionTimes = [];
  
  try {
    await ConfigManager.initialize();
    const db = ConfigManager.getDatabase();
    
    // Mock controller
    const reportController = {
      reportUrl: async (url) => {
        executionCount++;
        const now = new Date();
        executionTimes.push(now);
        
        console.log(`[${executionCount}] Report executed at ${now.toLocaleTimeString()}`);
        
        if (executionTimes.length > 1) {
          const diff = (now - executionTimes[executionTimes.length - 2]) / 1000;
          console.log(`    Time since last: ${diff.toFixed(1)} seconds`);
        }
        
        return { success: true, screenshotPath: 'test.png', error: null };
      }
    };
    
    // Create scheduler
    const scheduler = new SchedulerService(db, reportController);
    await scheduler.initialize();
    
    // Add report with 0.00278 hour interval (10 seconds)
    const intervalHours = 10 / 3600; // 10 seconds in hours
    console.log(`Creating report with interval: ${intervalHours} hours (10 seconds)\n`);
    
    const reportId = await scheduler.addScheduledReport(
      'https://quick-test.com',
      'test-user',
      intervalHours
    );
    
    // Wait for 35 seconds to see 3-4 executions
    console.log('Waiting 35 seconds for multiple executions...\n');
    await new Promise(resolve => setTimeout(resolve, 35000));
    
    // Show results
    console.log('\n📊 Results:');
    console.log(`Total executions: ${executionCount}`);
    console.log(`Expected: ~4 executions (1 initial + 3 intervals)`);
    
    if (executionTimes.length > 1) {
      const intervals = [];
      for (let i = 1; i < executionTimes.length; i++) {
        intervals.push((executionTimes[i] - executionTimes[i-1]) / 1000);
      }
      const avg = intervals.reduce((a,b) => a+b, 0) / intervals.length;
      console.log(`Average interval: ${avg.toFixed(1)} seconds (expected: 10)`);
    }
    
    // Cleanup
    await scheduler.shutdown();
    await db.deactivateScheduledReport(reportId);
    await db.close();
    
    console.log('\n✅ Test complete!');
    
  } catch (error) {
    console.error('❌ Error:', error);
  }
  
  process.exit(0);
}

quickTest();
