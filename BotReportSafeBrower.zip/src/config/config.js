require('dotenv').config();

const config = {
  browser: {
    headless: process.env.HEADLESS === 'true' || false,
    maxConcurrency: parseInt(process.env.MAX_CONCURRENCY) || 2,
    timeout: parseInt(process.env.TIMEOUT) || 30000,
    viewport: {
      width: parseInt(process.env.VIEWPORT_WIDTH) || 1280,
      height: parseInt(process.env.VIEWPORT_HEIGHT) || 800
    },
    userAgent: process.env.USER_AGENT || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114 Safari/537.36'
  },

  report: {
    defaultUrl: process.env.DEFAULT_REPORT_URL || 'https://xnxx.com',
    defaultMessage: process.env.DEFAULT_REPORT_MESSAGE || 'Inappropriate content detected',
    screenshotPath: process.env.SCREENSHOT_PATH || './screenshots/',
    reportDelay: parseInt(process.env.REPORT_DELAY) || 3000
  },

  telegram: {
    botToken: process.env.TELEGRAM_BOT_TOKEN || '',
    adminUsers: process.env.TELEGRAM_ADMIN_USERS ? process.env.TELEGRAM_ADMIN_USERS.split(',') : [],
    allowedUsers: process.env.TELEGRAM_ALLOWED_USERS ? process.env.TELEGRAM_ALLOWED_USERS.split(',') : [],
    adminChatId: process.env.TELEGRAM_ADMIN_CHAT_ID || ''
  },

  targets: {
    googleSafeBrowsing: 'https://safebrowsing.google.com/safebrowsing/report_phish/',
  },

  logging: {
    level: process.env.LOG_LEVEL || 'info',
    enableFileLogging: process.env.ENABLE_FILE_LOGGING === 'true' || false,
    logPath: process.env.LOG_PATH || './logs/'
  }
};

module.exports = config;
