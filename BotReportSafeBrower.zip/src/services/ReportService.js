const config = require('../config/config');
const logger = require('../utils/logger');
const Helpers = require('../utils/helpers');

class ReportService {
  constructor(browserService) {
    this.browserService = browserService;
  }

  async submitReport(targetUrl, options) {
    const {
      urlToReport,
      message,
      takeScreenshot
    } = options;

    try {
      const cluster = this.browserService.getCluster();
      
      const result = await cluster.execute(async ({ page }) => {
        await this.browserService.setupPage(page);
        await this.browserService.navigateToPage(page, targetUrl);
        await page.waitForSelector('input[formcontrolname="url"]', { timeout: 10000 });
        const urlInputSelectors = ['input[formcontrolname="url"]'];
        for (const selector of urlInputSelectors) {
          const element = await page.$(selector);
          if (element) {
            await element.click({ clickCount: 3 });
            await element.type(urlToReport);
            break;
          }
        }
        
        const messageSelectors = ['textarea[formcontrolname="details"]'];
        for (const selector of messageSelectors) {
          const element = await page.$(selector);
          if (element) {
            await element.click();
            await element.type(message || config.report.defaultMessage);
            break;
          }
        }
        
        await Helpers.randomDelay(1000, 2000);
        const submitSelectors = [
          'button[type="submit"]'
        ];
        
        let submitted = false;
        for (const selector of submitSelectors) {
          try {
            const element = await page.$(selector);
            if (element) {
              await element.click();
              submitted = true;
              break;
            }
          } catch (e) {
            logger.error(`Failed to submit report for ${urlToReport}`, Helpers.formatError(e));
          }
        }
        
        if (submitted) {
          await Helpers.randomDelay(3000, 10000);
        }
        try {
          const success = await page.evaluate(() => {
            const el = document.querySelector('status-tile mat-card-content');
            return el && el.innerText.includes('Submission was successful.');
          });
        
          if (success) {
            console.log("✅ Submission sukses");
          } else {
            console.log("❌ Submission gagal atau teks tidak ditemukan");
          }
        } catch (err) {
          console.error("Error cek status:", err);
        }
        let screenshotPath = null;
        if (takeScreenshot) {
          const filename = Helpers.generateFileName(urlToReport);
          screenshotPath = await this.browserService.takeScreenshot(page, filename);
        }
        return {
          success: submitted,
          urlReported: urlToReport,
          targetSite: targetUrl,
          screenshotPath,
          timestamp: new Date().toISOString()
        };
      });
      
      return result;
    } catch (error) {
      logger.error(`Failed to submit report for ${options.urlToReport}`, Helpers.formatError(error));
      throw error;
    }
  }

  async submitMultipleReports(reports) {
    const results = [];
    
    for (const report of reports) {
      try {
        const result = await this.submitReport(report.targetUrl, {
          urlToReport: report.urlToReport,
          message: report.message,
          takeScreenshot: report.takeScreenshot
        });
        
        results.push(result);
        await Helpers.randomDelay(config.report.reportDelay, config.report.reportDelay + 2000);
      } catch (error) {
        logger.error(`Failed to report ${report.urlToReport}`, Helpers.formatError(error));
        results.push({
          success: false,
          urlReported: report.urlToReport,
          error: error.message
        });
      }
    }
    
    return results;
  }
}

module.exports = ReportService;
