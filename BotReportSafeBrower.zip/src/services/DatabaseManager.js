const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const logger = require('../utils/logger');
const Helpers = require('../utils/helpers');

class DatabaseManager {
  constructor() {
    this.db = null;
    this.dbPath = path.join(process.cwd(), 'data', 'bot.db');
  }

  async initialize() {
    try {
      Helpers.ensureDirectory(path.dirname(this.dbPath));
      
      return new Promise((resolve, reject) => {
        this.db = new sqlite3.Database(this.dbPath, (err) => {
          if (err) {
            logger.error('Failed to connect to database', err);
            reject(err);
          } else {
            logger.info('Connected to SQLite database');
            this.createTables().then(resolve).catch(reject);
          }
        });
      });
    } catch (error) {
      logger.error('Failed to initialize database', Helpers.formatError(error));
      throw error;
    }
  }

  async createTables() {
    const queries = [
      `CREATE TABLE IF NOT EXISTS config (
        key TEXT PRIMARY KEY,
        value TEXT,
        type TEXT DEFAULT 'string',
        description TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,

      `CREATE TABLE IF NOT EXISTS users (
        user_id TEXT PRIMARY KEY,
        username TEXT,
        added_by TEXT,
        added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        expires_at DATETIME,
        is_admin INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1
      )`,
      
      `CREATE TABLE IF NOT EXISTS scheduled_reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        url TEXT NOT NULL,
        user_id TEXT NOT NULL,
        interval_hours REAL NOT NULL,
        last_run DATETIME,
        next_run DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        is_active INTEGER DEFAULT 1,
        run_count INTEGER DEFAULT 0,
        FOREIGN KEY (user_id) REFERENCES users(user_id)
      )`,
      
      `CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action TEXT NOT NULL,
        performed_by TEXT NOT NULL,
        target_user TEXT,
        details TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS report_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        url TEXT NOT NULL,
        user_id TEXT NOT NULL,
        success INTEGER DEFAULT 1,
        screenshot_path TEXT,
        error_message TEXT,
        reported_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`
    ];

    for (const query of queries) {
      await this.run(query);
    }
    
    await this.initializeDefaultConfig();
    
    logger.info('Database tables created successfully');
  }

  async getConfig(key) {
    return new Promise((resolve, reject) => {
      this.db.get('SELECT value, type FROM config WHERE key = ?', [key], (err, row) => {
        if (err) reject(err);
        else if (row) {
          let value = row.value;
          if (row.type === 'boolean') value = value === 'true';
          else if (row.type === 'integer') value = parseInt(value);
          else if (row.type === 'float') value = parseFloat(value);
          else if (row.type === 'json') value = JSON.parse(value);
          resolve(value);
        } else {
          resolve(null);
        }
      });
    });
  }

  async setConfig(key, value, type = 'string', description = '') {
    let stringValue = value;
    if (type === 'boolean') stringValue = value ? 'true' : 'false';
    else if (type === 'json') stringValue = JSON.stringify(value);
    else stringValue = value.toString();

    return this.run(
      `INSERT OR REPLACE INTO config (key, value, type, description, updated_at) 
       VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)`,
      [key, stringValue, type, description]
    );
  }

  async getAllConfig() {
    return new Promise((resolve, reject) => {
      this.db.all('SELECT * FROM config ORDER BY key', (err, rows) => {
        if (err) reject(err);
        else {
          const config = {};
          rows.forEach(row => {
            let value = row.value;
            if (row.type === 'boolean') value = value === 'true';
            else if (row.type === 'integer') value = parseInt(value);
            else if (row.type === 'float') value = parseFloat(value);
            else if (row.type === 'json') value = JSON.parse(value);
            config[row.key] = { value, type: row.type, description: row.description };
          });
          resolve(config);
        }
      });
    });
  }

  async setConfigIfNotExists(key, value, type = 'string', description = '') {
    const existing = await this.getConfig(key);
    if (!existing) {
      await this.setConfig(key, value, type, description);
    }
  }

  async initializeDefaultConfig() {
    const defaultConfig = {
      'browser.headless': { value: 'false', type: 'boolean', description: 'Run browser in headless mode' },
      'browser.maxConcurrency': { value: '2', type: 'integer', description: 'Maximum concurrent browser instances' },
      'browser.timeout': { value: '30000', type: 'integer', description: 'Browser timeout in milliseconds' },
      'browser.viewportWidth': { value: '1280', type: 'integer', description: 'Browser viewport width' },
      'browser.viewportHeight': { value: '800', type: 'integer', description: 'Browser viewport height' },
      'browser.userAgent': { value: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', type: 'string', description: 'Browser user agent' },
      
      'report.defaultUrl': { value: 'https://xnxx.com', type: 'string', description: 'Default URL for reporting' },
      'report.defaultMessage': { value: 'Inappropriate content detected', type: 'string', description: 'Default report message' },
      'report.screenshotPath': { value: './screenshots/', type: 'string', description: 'Path to save screenshots' },
      'report.reportDelay': { value: '3000', type: 'integer', description: 'Delay before report in milliseconds' },
      
      'telegram.botToken': { value: '7966612781:AAFsADqAhNl7aCD-V3v814ZQYXukp2K553g', type: 'string', description: 'Telegram bot token' },
      'telegram.adminChatId': { value: '5219633203', type: 'string', description: 'Admin chat ID for notifications' },
      
      'logging.level': { value: 'info', type: 'string', description: 'Logging level (debug, info, warn, error)' },
      'logging.enableFileLogging': { value: 'true', type: 'boolean', description: 'Enable file logging' },
      'logging.logPath': { value: './logs/', type: 'string', description: 'Path to save log files' }
    };

    for (const [key, config] of Object.entries(defaultConfig)) {
      await this.setConfigIfNotExists(key, config.value, config.type, config.description);
    }

    await this.addUser('5219633203', 'Admin', 'SYSTEM', 365, true);
  }

  async addUser(userId, username, addedBy, expiryDays, isAdmin = false) {
    const expiresAt = expiryDays ? 
      new Date(Date.now() + expiryDays * 24 * 60 * 60 * 1000).toISOString() : 
      null;
    
    const query = `
      INSERT OR REPLACE INTO users (user_id, username, added_by, expires_at, is_admin, is_active)
      VALUES (?, ?, ?, ?, ?, 1)
    `;
    
    await this.run(query, [userId, username, addedBy, expiresAt, isAdmin ? 1 : 0]);
    
    await this.logAction('ADD_USER', addedBy, userId, `Added user with ${expiryDays ? expiryDays + ' days' : 'no'} expiry`);
    
    return { userId, username, expiresAt, isAdmin };
  }

  async removeUser(userId, removedBy) {
    const query = `UPDATE users SET is_active = 0 WHERE user_id = ?`;
    await this.run(query, [userId]);
    
    await this.run(`UPDATE scheduled_reports SET is_active = 0 WHERE user_id = ?`, [userId]);
    
    await this.logAction('REMOVE_USER', removedBy, userId, 'User access revoked');
  }

  async getUser(userId) {
    const query = `SELECT * FROM users WHERE user_id = ? AND is_active = 1`;
    return await this.get(query, [userId]);
  }

  async isUserAuthorized(userId) {
    const user = await this.getUser(userId);
    if (!user) return false;
    
    if (user.expires_at && new Date(user.expires_at) < new Date()) {
      await this.removeUser(userId, 'SYSTEM');
      return false;
    }
    
    return true;
  }

  async isUserAdmin(userId) {
    const user = await this.getUser(userId);
    return user && user.is_admin === 1;
  }

  async listUsers() {
    const query = `
      SELECT user_id, username, added_by, added_at, expires_at, is_admin 
      FROM users 
      WHERE is_active = 1 
      ORDER BY is_admin DESC, added_at DESC
    `;
    return await this.all(query);
  }

  async getAdminUsers() {
    const query = `SELECT user_id FROM users WHERE is_admin = 1`;
    return await this.all(query);
  }

  async cleanupExpiredUsers() {
    const query = `
      UPDATE users 
      SET is_active = 0 
      WHERE is_active = 1 AND expires_at IS NOT NULL AND expires_at < datetime('now')
    `;
    const result = await this.run(query);
    
    if (result.changes > 0) {
      logger.info(`Cleaned up ${result.changes} expired users`);
      
      const reportQuery = `
        UPDATE scheduled_reports 
        SET is_active = 0 
        WHERE user_id IN (
          SELECT user_id FROM users 
          WHERE is_active = 0 AND expires_at < datetime('now')
        )
      `;
      await this.run(reportQuery);
    }
    
    return result.changes;
  }

  async listUsers() {
    const query = `
      SELECT user_id, username, added_by, added_at, expires_at, is_admin 
      FROM users 
      WHERE is_active = 1 
      ORDER BY is_admin DESC, added_at DESC
    `;
    return await this.all(query);
  }

  async cleanupExpiredUsers() {
    const query = `
      UPDATE users 
      SET is_active = 0 
      WHERE is_active = 1 AND expires_at IS NOT NULL AND expires_at < datetime('now')
    `;
    const result = await this.run(query);
    
    if (result.changes > 0) {
      logger.info(`Cleaned up ${result.changes} expired users`);
      
      const reportQuery = `
        UPDATE scheduled_reports 
        SET is_active = 0 
        WHERE user_id IN (
          SELECT user_id FROM users 
          WHERE is_active = 0 AND expires_at < datetime('now')
        )
      `;
      await this.run(reportQuery);
    }
    
    return result.changes;
  }

  async addScheduledReport(url, userId, intervalHours) {
    const nextRun = new Date(Date.now() + intervalHours * 60 * 60 * 1000).toISOString();
    
    const query = `
      INSERT INTO scheduled_reports (url, user_id, interval_hours, next_run, is_active)
      VALUES (?, ?, ?, ?, 1)
    `;
    
    const result = await this.run(query, [url, userId, intervalHours, nextRun]);
    return result.lastID;
  }

  async stopScheduledReport(url, userId) {
    const query = `
      UPDATE scheduled_reports 
      SET is_active = 0 
      WHERE url = ? AND user_id = ? AND is_active = 1
    `;
    
    const result = await this.run(query, [url, userId]);
    return result.changes > 0;
  }

  async getScheduledReports(userId = null) {
    let query = `
      SELECT sr.*, u.username 
      FROM scheduled_reports sr
      JOIN users u ON sr.user_id = u.user_id
      WHERE sr.is_active = 1
    `;
    
    const params = [];
    if (userId) {
      query += ` AND sr.user_id = ?`;
      params.push(userId);
    }
    
    query += ` ORDER BY sr.next_run ASC`;
    
    return await this.all(query, params);
  }

  async getReportsToRun() {
    const query = `
      SELECT sr.*, u.username 
      FROM scheduled_reports sr
      JOIN users u ON sr.user_id = u.user_id
      WHERE sr.is_active = 1 
        AND sr.next_run <= datetime('now')
        AND u.is_active = 1
      ORDER BY sr.next_run ASC
    `;
    
    return await this.all(query);
  }

  async updateScheduledReport(reportId, lastRun, nextRun) {
    const query = `
      UPDATE scheduled_reports 
      SET last_run = ?, next_run = ?, run_count = run_count + 1
      WHERE id = ?
    `;
    
    await this.run(query, [lastRun, nextRun, reportId]);
  }

  async addReportHistory(url, userId, success, screenshotPath = null, errorMessage = null) {
    const query = `
      INSERT INTO report_history (url, user_id, success, screenshot_path, error_message)
      VALUES (?, ?, ?, ?, ?)
    `;
    
    await this.run(query, [url, userId, success ? 1 : 0, screenshotPath, errorMessage]);
  }

  async getActiveScheduledReports() {
    const query = `
      SELECT * FROM scheduled_reports 
      WHERE is_active = 1
      ORDER BY next_run ASC
    `;
    return await this.all(query);
  }

  async getScheduledReport(reportId) {
    const query = `SELECT * FROM scheduled_reports WHERE id = ?`;
    return await this.get(query, [reportId]);
  }

  async getScheduledReportsByUrl(url, userId) {
    const query = `
      SELECT * FROM scheduled_reports 
      WHERE url = ? AND user_id = ? AND is_active = 1
    `;
    return await this.all(query, [url, userId]);
  }

  async getScheduledReportsByUser(userId) {
    const query = `
      SELECT * FROM scheduled_reports 
      WHERE user_id = ? AND is_active = 1
      ORDER BY created_at DESC
    `;
    return await this.all(query, [userId]);
  }

  async updateScheduledReportLastRun(reportId) {
    const query = `
      UPDATE scheduled_reports 
      SET last_run = datetime('now')
      WHERE id = ?
    `;
    await this.run(query, [reportId]);
  }

  async incrementScheduledReportRunCount(reportId) {
    const query = `
      UPDATE scheduled_reports 
      SET run_count = run_count + 1
      WHERE id = ?
    `;
    await this.run(query, [reportId]);
  }

  async getScheduledReportFailureCount(reportId) {
    const query = `
      SELECT COUNT(*) as failure_count
      FROM report_history rh
      JOIN scheduled_reports sr ON rh.url = sr.url AND rh.user_id = sr.user_id
      WHERE sr.id = ? 
        AND rh.success = 0
        AND rh.created_at > datetime('now', '-24 hours')
    `;
    const result = await this.get(query, [reportId]);
    return result ? result.failure_count : 0;
  }

  async deactivateScheduledReport(reportId) {
    const query = `
      UPDATE scheduled_reports 
      SET is_active = 0
      WHERE id = ?
    `;
    await this.run(query, [reportId]);
  }

  async getReportHistory(userId = null, limit = 50) {
    let query = `
      SELECT rh.*, u.username 
      FROM report_history rh
      JOIN users u ON rh.user_id = u.user_id
    `;
    
    const params = [];
    if (userId) {
      query += ` WHERE rh.user_id = ?`;
      params.push(userId);
    }
    
    query += ` ORDER BY rh.reported_at DESC LIMIT ?`;
    params.push(limit);
    
    return await this.all(query, params);
  }

  async logAction(action, performedBy, targetUser = null, details = null) {
    const query = `
      INSERT INTO audit_log (action, performed_by, target_user, details)
      VALUES (?, ?, ?, ?)
    `;
    
    await this.run(query, [action, performedBy, targetUser, details]);
  }

  async getAuditLog(limit = 100) {
    const query = `
      SELECT * FROM audit_log 
      ORDER BY timestamp DESC 
      LIMIT ?
    `;
    
    return await this.all(query, [limit]);
  }

  run(query, params = []) {
    return new Promise((resolve, reject) => {
      this.db.run(query, params, function(err) {
        if (err) {
          logger.error('Database query error', { query, error: err });
          reject(err);
        } else {
          resolve({ lastID: this.lastID, changes: this.changes });
        }
      });
    });
  }

  get(query, params = []) {
    return new Promise((resolve, reject) => {
      this.db.get(query, params, (err, row) => {
        if (err) {
          logger.error('Database query error', { query, error: err });
          reject(err);
        } else {
          resolve(row);
        }
      });
    });
  }

  all(query, params = []) {
    return new Promise((resolve, reject) => {
      this.db.all(query, params, (err, rows) => {
        if (err) {
          logger.error('Database query error', { query, error: err });
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }

  async close() {
    return new Promise((resolve, reject) => {
      if (this.db) {
        this.db.close((err) => {
          if (err) {
            logger.error('Failed to close database', err);
            reject(err);
          } else {
            logger.info('Database connection closed');
            resolve();
          }
        });
      } else {
        resolve();
      }
    });
  }
}

module.exports = DatabaseManager;
