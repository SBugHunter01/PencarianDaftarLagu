const { Cluster } = require('puppeteer-cluster');
const ConfigManager = require('../services/ConfigManager');
const logger = require('../utils/logger');
const Helpers = require('../utils/helpers');

class BrowserService {
  constructor() {
    this.cluster = null;
    this.isInitialized = false;
    this.config;
  }

  async initialize() {
    if (this.isInitialized) {
      logger.warn('BrowserService already initialized');
      return;
    }

    try {
      logger.info('Initializing browser cluster...');
      
      this.config = await ConfigManager.getStructuredConfig();
      
      this.cluster = await Cluster.launch({
        puppeteer: require('undetected-puppeteer'),
        concurrency: Cluster.CONCURRENCY_CONTEXT,
        maxConcurrency: this.config.browser.maxConcurrency,
        timeout: this.config.browser.timeout,
        puppeteerOptions: {
          headless: this.config.browser.headless,
          args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-blink-features=AutomationControlled',
            '--disable-web-security',
            '--disable-features=IsolateOrigins,site-per-process',
            `--window-size=${this.config.browser.viewport.width},${this.config.browser.viewport.height}`
          ]
        },
      });

      this.isInitialized = true;
      logger.info('Browser cluster initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize browser cluster', Helpers.formatError(error));
      throw error;
    }
  }

  async setupPage(page) {
    try {
      await page.setUserAgent(this.config.browser.userAgent);
      await page.setViewport(this.config.browser.viewport);
      await page.setExtraHTTPHeaders({
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
      });

    } catch (error) {
      logger.error('Failed to setup page', Helpers.formatError(error));
      throw error;
    }
  }

  async navigateToPage(page, url) {
    try {
      logger.info(`Navigating to: ${url}`);
      
      await page.goto(url, { 
        waitUntil: 'domcontentloaded',
        timeout: this.config.browser.timeout 
      });
      
      await Helpers.humanMouse(page);
      await Helpers.randomDelay(1000, 2000);
      
      logger.info(`Successfully navigated to: ${url}`);
    } catch (error) {
      logger.error(`Failed to navigate to ${url}`, Helpers.formatError(error));
      throw error;
    }
  }

  async takeScreenshot(page, filename) {
    try {
      Helpers.ensureDirectory(this.config.report.screenshotPath);
      const fullPath = `${this.config.report.screenshotPath}${filename}`;
      
      await page.screenshot({ 
        path: fullPath, 
        fullPage: true,
      });
      
      logger.info(`Screenshot saved: ${fullPath}`);
      return fullPath;
    } catch (error) {
      logger.error('Failed to take screenshot', Helpers.formatError(error));
      throw error;
    }
  }

  async close() {
    if (this.cluster) {
      try {
        await this.cluster.idle();
        await this.cluster.close();
        this.isInitialized = false;
        logger.info('Browser cluster closed successfully');
      } catch (error) {
        logger.error('Failed to close browser cluster', Helpers.formatError(error));
      }
    }
  }

  getCluster() {
    if (!this.isInitialized) {
      throw new Error('BrowserService not initialized. Call initialize() first.');
    }
    return this.cluster;
  }
}

module.exports = BrowserService;
