const DatabaseManager = require('./DatabaseManager');
const logger = require('../utils/logger');

class ConfigManager {
  constructor() {
    this.db = null;
    this.cache = {};
    this.initialized = false;
  }

  async initialize() {
    try {
      this.db = new DatabaseManager();
      await this.db.initialize();
      await this.loadCache();
      this.initialized = true;
      logger.info('ConfigManager initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize ConfigManager', error);
      throw error;
    }
  }

  async loadCache() {
    const allConfig = await this.db.getAllConfig();
    this.cache = {};
    for (const [key, config] of Object.entries(allConfig)) {
      this.cache[key] = config.value;
    }
  }

  async get(key, defaultValue = null) {
    if (!this.initialized) {
      await this.initialize();
    }
    
    if (key in this.cache) {
      return this.cache[key];
    }
    
    const value = await this.db.getConfig(key);
    if (value !== null) {
      this.cache[key] = value;
      return value;
    }
    
    return defaultValue;
  }

  async set(key, value, type = 'string', description = '') {
    if (!this.initialized) {
      await this.initialize();
    }
    
    await this.db.setConfig(key, value, type, description);
    this.cache[key] = value;
    logger.info(`Configuration updated: ${key} = ${value}`);
  }

  async getAll() {
    if (!this.initialized) {
      await this.initialize();
    }
    
    return await this.db.getAllConfig();
  }

  async getStructuredConfig() {
    if (!this.initialized) {
      await this.initialize();
    }
    
    return {
      browser: {
        headless: await this.get('browser.headless', false),
        maxConcurrency: await this.get('browser.maxConcurrency', 2),
        timeout: await this.get('browser.timeout', 30000),
        viewport: {
          width: await this.get('browser.viewportWidth', 1280),
          height: await this.get('browser.viewportHeight', 800)
        },
        userAgent: await this.get('browser.userAgent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
      },
      report: {
        defaultUrl: await this.get('report.defaultUrl', 'https://xnxx.com'),
        defaultMessage: await this.get('report.defaultMessage', 'Inappropriate content detected'),
        screenshotPath: await this.get('report.screenshotPath', './screenshots/'),
        reportDelay: await this.get('report.reportDelay', 3000)
      },
      telegram: {
        botToken: await this.get('telegram.botToken', ''),
        adminChatId: await this.get('telegram.adminChatId', '')
      },
      targets: {
        googleSafeBrowsing: 'https://safebrowsing.google.com/safebrowsing/report_phish/'
      },
      logging: {
        level: await this.get('logging.level', 'info'),
        enableFileLogging: await this.get('logging.enableFileLogging', true),
        logPath: await this.get('logging.logPath', './logs/')
      }
    };
  }

  getDatabase() {
    return this.db;
  }

  async isBotConfigured() {
    const token = await this.get('telegram.botToken', '');
    return token && token.length > 0;
  }

  async updateMultiple(configs) {
    if (!this.initialized) {
      await this.initialize();
    }
    
    for (const [key, data] of Object.entries(configs)) {
      await this.set(key, data.value, data.type || 'string', data.description || '');
    }
  }

  async exportConfig() {
    const allConfig = await this.getAll();
    return JSON.stringify(allConfig, null, 2);
  }

  async importConfig(jsonString) {
    try {
      const configs = JSON.parse(jsonString);
      await this.updateMultiple(configs);
      await this.loadCache();
      logger.info('Configuration imported successfully');
    } catch (error) {
      logger.error('Failed to import configuration', error);
      throw new Error('Invalid configuration format');
    }
  }
}

module.exports = new ConfigManager();
