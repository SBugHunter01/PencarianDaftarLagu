const logger = require('../utils/logger');
const Helpers = require('../utils/helpers');

class SchedulerService {
  constructor(database, reportController, bot = null) {
    this.db = database;
    this.reportController = reportController;
    this.bot = bot;
    this.scheduledJobs = new Map();
    this.isRunning = false;
  }

  async initialize() {
    try {
      logger.info('Initializing SchedulerService...');
      await this.loadScheduledReports();
      this.isRunning = true;
      logger.info('SchedulerService initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize SchedulerService', Helpers.formatError(error));
      throw error;
    }
  }

  async loadScheduledReports() {
    try {
      const reports = await this.db.getActiveScheduledReports();
      
      for (const report of reports) {
        this.scheduleReport(report);
      }
      
      logger.info(`Loaded ${reports.length} scheduled reports`);
    } catch (error) {
      logger.error('Error loading scheduled reports', Helpers.formatError(error));
    }
  }

  scheduleReport(report) {
    if (this.scheduledJobs.has(report.id)) {
      return;
    }

    const intervalMs = report.interval_hours * 60 * 60 * 1000;
    const lastRun = report.last_run ? new Date(report.last_run) : null;
    const now = new Date();
    
    let timeUntilFirstRun = 0;
    
    if (lastRun) {
      const nextRun = new Date(lastRun.getTime() + intervalMs);
      timeUntilFirstRun = Math.max(0, nextRun.getTime() - now.getTime());
    } else {
      timeUntilFirstRun = 0;
    }
    
    if (timeUntilFirstRun === 0) {
      this.runScheduledReport(report);
      const intervalId = setInterval(async () => {
        await this.runScheduledReport(report);
      }, intervalMs);
      
      this.scheduledJobs.set(report.id, intervalId);
    } else {
      const timeoutId = setTimeout(() => {
        this.runScheduledReport(report);
        const intervalId = setInterval(async () => {
          await this.runScheduledReport(report);
        }, intervalMs);
        
        this.scheduledJobs.set(report.id, intervalId);
      }, timeUntilFirstRun);
      
      this.scheduledJobs.set(report.id, timeoutId);
    }
    
    const intervalHours = report.interval_hours;
    const intervalMinutes = intervalHours * 60;
    const intervalSeconds = intervalMinutes * 60;
    logger.info(`Scheduled report ${report.id} for URL ${report.url} every ${intervalHours} hours (${intervalMinutes} minutes, ${intervalSeconds} seconds)`);
  }

  async runScheduledReport(report) {
    try {
      logger.info(`Running scheduled report ${report.id} for URL: ${report.url}`);
      await this.db.updateScheduledReportLastRun(report.id);
      const result = await this.reportController.reportUrl(report.url, {
        userId: report.user_id,
        scheduled: true,
        reportId: report.id,
        username: 'Scheduler'
      });
      await this.db.addReportHistory(
        report.url,
        report.user_id,
        result.success,
        result.screenshotPath,
        result.error || null
      );
      
      await this.db.incrementScheduledReportRunCount(report.id);
      
      if (result.success) {
        logger.info(`Scheduled report ${report.id} completed successfully`);
      } else {
        logger.error(`Scheduled report ${report.id} failed: ${result.error}`);
        const failureCount = await this.db.getScheduledReportFailureCount(report.id);
        if (failureCount >= 5) {
          await this.stopScheduledReport(report.id);
          logger.warn(`Deactivated scheduled report ${report.id} due to repeated failures`);
        }
      }
      
    } catch (error) {
      logger.error(`Error running scheduled report ${report.id}`, Helpers.formatError(error));
    }
  }



  async addScheduledReport(url, userId, intervalHours) {
    try {
      const reportId = await this.db.addScheduledReport(url, userId, intervalHours);
      const report = await this.db.getScheduledReport(reportId);
      if (report) {
        this.scheduleReport(report);
      }
      
      return reportId;
    } catch (error) {
      logger.error('Error adding scheduled report', Helpers.formatError(error));
      throw error;
    }
  }

  async stopScheduledReport(reportId) {
    try {
      if (this.scheduledJobs.has(reportId)) {
        clearInterval(this.scheduledJobs.get(reportId));
        this.scheduledJobs.delete(reportId);
        logger.info(`Stopped scheduled job for report ${reportId}`);
      }
      
      await this.db.deactivateScheduledReport(reportId);
      
      return true;
    } catch (error) {
      logger.error('Error stopping scheduled report', Helpers.formatError(error));
      return false;
    }
  }

  async stopScheduledReportByUrl(url, userId) {
    try {
      const reports = await this.db.getScheduledReportsByUrl(url, userId);
      
      for (const report of reports) {
        await this.stopScheduledReport(report.id);
      }
      
      return reports.length > 0;
    } catch (error) {
      logger.error('Error stopping scheduled reports by URL', Helpers.formatError(error));
      return false;
    }
  }

  async getScheduledReports(userId = null) {
    try {
      if (userId) {
        return await this.db.getScheduledReportsByUser(userId);
      } else {
        return await this.db.getActiveScheduledReports();
      }
    } catch (error) {
      logger.error('Error getting scheduled reports', Helpers.formatError(error));
      return [];
    }
  }

  async shutdown() {
    logger.info('Shutting down SchedulerService...');
    for (const [reportId, timerId] of this.scheduledJobs) {
      clearInterval(timerId);
      clearTimeout(timerId);
    }
    this.scheduledJobs.clear();
    
    this.isRunning = false;
    logger.info('SchedulerService shutdown complete');
  }

  getStatus() {
    return {
      isRunning: this.isRunning,
      activeJobs: this.scheduledJobs.size,
      jobIds: Array.from(this.scheduledJobs.keys())
    };
  }
}

module.exports = SchedulerService;
