const ConfigManager = require('./services/ConfigManager');
const readline = require('readline');
const logger = require('./utils/logger');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function question(prompt) {
  return new Promise((resolve) => {
    rl.question(prompt, (answer) => {
      resolve(answer);
    });
  });
}

async function setup() {
  console.log('🚀 Bot Report Safe Browser - Configuration Setup\n');
  console.log('This utility will help you configure the application.\n');
  
  try {
    await ConfigManager.initialize();
    console.log('✅ Database initialized\n');
    
    const currentToken = await ConfigManager.get('telegram.botToken', '');
    if (currentToken) {
      console.log('📌 Telegram bot token is already configured.');
      const update = await question('Do you want to update it? (y/n): ');
      if (update.toLowerCase() !== 'y') {
        console.log('Skipping Telegram bot token...\n');
      } else {
        const token = await question('Enter your Telegram bot token: ');
        if (token) {
          await ConfigManager.set('telegram.botToken', token, 'string', 'Telegram bot token');
          console.log('✅ Telegram bot token updated\n');
        }
      }
    } else {
      const token = await question('Enter your Telegram bot token (or press Enter to skip): ');
      if (token) {
        await ConfigManager.set('telegram.botToken', token, 'string', 'Telegram bot token');
        console.log('✅ Telegram bot token saved\n');
      }
    }
    
    const currentAdmins = await ConfigManager.get('telegram.adminUsers', '');
    if (currentAdmins) {
      console.log(`📌 Current admin users: ${currentAdmins}`);
      const update = await question('Do you want to update admin users? (y/n): ');
      if (update.toLowerCase() === 'y') {
        const admins = await question('Enter admin user IDs (comma-separated): ');
        if (admins) {
          await ConfigManager.set('telegram.adminUsers', admins, 'string', 'Admin user IDs');
          console.log('✅ Admin users updated\n');
        }
      }
    } else {
      const admins = await question('Enter admin user IDs (comma-separated, or press Enter to skip): ');
      if (admins) {
        await ConfigManager.set('telegram.adminUsers', admins, 'string', 'Admin user IDs');
        console.log('✅ Admin users saved\n');
      }
    }
    
    console.log('\n🌐 Browser Configuration:');
    const headless = await question('Run browser in headless mode? (y/n, default: n): ');
    if (headless) {
      await ConfigManager.set('browser.headless', headless.toLowerCase() === 'y', 'boolean', 'Run browser in headless mode');
    }
    
    const concurrency = await question('Maximum concurrent browsers (default: 2): ');
    if (concurrency && !isNaN(concurrency)) {
      await ConfigManager.set('browser.maxConcurrency', parseInt(concurrency), 'integer', 'Maximum concurrent browser instances');
    }
    
    console.log('\n📝 Report Configuration:');
    const screenshotPath = await question('Screenshot save path (default: ./screenshots/): ');
    if (screenshotPath) {
      await ConfigManager.set('report.screenshotPath', screenshotPath, 'string', 'Path to save screenshots');
    }
    
    console.log('\n✅ Configuration complete!\n');
    console.log('📋 Current Configuration:');
    const config = await ConfigManager.getStructuredConfig();
    
    console.log('\nTelegram:');
    console.log(`  Bot Token: ${config.telegram.botToken ? '***configured***' : 'not configured'}`);
    console.log(`  Admin Users: ${await ConfigManager.get('telegram.adminUsers', 'not configured')}`);
    
    console.log('\nBrowser:');
    console.log(`  Headless: ${config.browser.headless}`);
    console.log(`  Max Concurrency: ${config.browser.maxConcurrency}`);
    console.log(`  Timeout: ${config.browser.timeout}ms`);
    
    console.log('\nReport:');
    console.log(`  Screenshot Path: ${config.report.screenshotPath}`);
    console.log(`  Report Delay: ${config.report.reportDelay}ms`);
    
    console.log('\n💡 You can modify these settings anytime using:');
    console.log('   - The /setconfig command in Telegram (admin only)');
    console.log('   - Running this setup again: npm run setup');
    console.log('\n🚀 To start the application, run: npm start');
    
  } catch (error) {
    console.error('❌ Setup failed:', error.message);
    process.exit(1);
  } finally {
    rl.close();
  }
}

setup().catch(console.error);
