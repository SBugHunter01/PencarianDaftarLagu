const fs = require('fs');
const path = require('path');
const config = require('../config/config');

class Logger {
  constructor() {
    this.logLevel = config.logging.level;
    this.enableFileLogging = config.logging.enableFileLogging;
    this.logPath = config.logging.logPath;
    
    if (this.enableFileLogging) {
      this.ensureLogDirectory();
    }
  }

  ensureLogDirectory() {
    if (!fs.existsSync(this.logPath)) {
      fs.mkdirSync(this.logPath, { recursive: true });
    }
  }

  formatMessage(level, message, data = null) {
    const timestamp = new Date().toISOString();
    const logMessage = `[${timestamp}] [${level.toUpperCase()}] ${message}`;
    
    if (data) {
      return `${logMessage} ${JSON.stringify(data, null, 2)}`;
    }
    
    return logMessage;
  }

  writeToFile(level, message, data = null) {
    if (!this.enableFileLogging) return;
    
    const logMessage = this.formatMessage(level, message, data);
    const logFile = path.join(this.logPath, `${new Date().toISOString().split('T')[0]}.log`);
    
    fs.appendFileSync(logFile, logMessage + '\n');
  }

  log(level, message, data = null) {
    const formattedMessage = this.formatMessage(level, message, data);
    
    switch (level) {
      case 'error':
        console.error(formattedMessage);
        break;
      case 'warn':
        console.warn(formattedMessage);
        break;
      case 'info':
        console.info(formattedMessage);
        break;
      case 'debug':
        console.debug(formattedMessage);
        break;
      default:
        console.log(formattedMessage);
    }
    
    this.writeToFile(level, message, data);
  }

  error(message, data = null) {
    this.log('error', message, data);
  }

  warn(message, data = null) {
    this.log('warn', message, data);
  }

  info(message, data = null) {
    this.log('info', message, data);
  }

  debug(message, data = null) {
    this.log('debug', message, data);
  }
}

module.exports = new Logger();
