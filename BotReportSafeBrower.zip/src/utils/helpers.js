const fs = require('fs');
const path = require('path');

class Helpers {
  static sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  static async humanMouse(page, iterations = 20) {
    const viewport = await page.viewport();
    
    for (let i = 0; i < iterations; i++) {
      const x = Math.floor(Math.random() * viewport.width);
      const y = Math.floor(Math.random() * viewport.height);
      await page.mouse.move(x, y, { steps: 5 });
      await this.sleep(Math.random() * 100 + 50);
    }
  }

  static generateFileName(url, extension = 'png') {
    const sanitized = url
      .replace(/https?:\/\//, '')
      .replace(/\W+/g, '_')
      .substring(0, 100); 
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    return `${sanitized}_${timestamp}.${extension}`;
  }

  static ensureDirectory(dirPath) {
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }
  }

  static sanitizeInput(input) {
    if (typeof input !== 'string') return '';
    
    return input
      .trim()
      .replace(/[<>]/g, '') 
      .substring(0, 1000);
  }

  static isValidUrl(string) {
    try {
      new URL(string);
      return true;
    } catch (_) {
      return false;
    }
  }

  static formatError(error) {
    return {
      message: error.message,
      stack: error.stack,
      timestamp: new Date().toISOString()
    };
  }

  static async randomDelay(min = 1000, max = 3000) {
    const delay = Math.floor(Math.random() * (max - min + 1)) + min;
    await this.sleep(delay);
  }
}

module.exports = Helpers;
