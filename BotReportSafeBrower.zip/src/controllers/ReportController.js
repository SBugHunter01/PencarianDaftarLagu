const BrowserService = require('../services/BrowserService');
const ReportService = require('../services/ReportService');
const ConfigManager = require('../services/ConfigManager');
const logger = require('../utils/logger');
const Helpers = require('../utils/helpers');

class ReportController {
  constructor(bot = null, database = null) {
    this.browserService = new BrowserService();
    this.reportService = new ReportService(this.browserService);
    this.isInitialized = false;
    this.config;
    this.bot = bot;
    this.db = database;
  }

  async initialize() {
    if (this.isInitialized) {
      logger.warn('ReportController already initialized');
      return;
    }

    try {
      await this.browserService.initialize();
      this.config = await ConfigManager.getStructuredConfig();
      this.isInitialized = true;
      logger.info('ReportController initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize ReportController', Helpers.formatError(error));
      throw error;
    }
  }

  async reportUrl(urlToReport, options = {}) {
    if (!this.isInitialized) {
      throw new Error('ReportController not initialized. Call initialize() first.');
    }

    console.log(this.config)

    const {
      targetSite = 'googleSafeBrowsing',
      message = this.config.report.defaultMessage,
      takeScreenshot = true,
      userId = null,
      username = null,
      chatId = null,
      intervalHours = null,
      scheduled = false,
      reportId = null
    } = options;

    try {
      if (!Helpers.isValidUrl(urlToReport)) {
        throw new Error('Invalid URL provided');
      }

      const targetUrl = this.getTargetUrl(targetSite);
      
      logger.info(`Reporting URL: ${urlToReport} to ${targetSite}`);
      
      const result = await this.reportService.submitReport(targetUrl, {
        urlToReport,
        message,
        takeScreenshot
      });

      logger.info(`Successfully reported URL: ${urlToReport}`);
      
      // Send Telegram notifications if bot and database are available
      if (result.success && this.bot && this.db) {
        await this.sendTelegramNotifications(urlToReport, result, {
          userId,
          username,
          chatId,
          intervalHours,
          scheduled,
          reportId
        });
      }
      
      return result;
      
    } catch (error) {
      logger.error(`Failed to report URL: ${urlToReport}`, Helpers.formatError(error));
      throw error;
    }
  }

  async reportMultipleUrls(urls, options = {}) {
    if (!this.isInitialized) {
      throw new Error('ReportController not initialized. Call initialize() first.');
    }

    const {
      targetSite = 'googleSafeBrowsing',
      message = this.config.report.defaultMessage,
      takeScreenshot = true
    } = options;

    try {
      const validUrls = urls.filter(url => Helpers.isValidUrl(url));
      if (validUrls.length === 0) {
        throw new Error('No valid URLs provided');
      }

      const targetUrl = this.getTargetUrl(targetSite);
      
      const reports = validUrls.map(url => ({
        targetUrl,
        urlToReport: url,
        message,
        takeScreenshot
      }));

      logger.info(`Reporting ${reports.length} URLs to ${targetSite}`);
      
      const results = await this.reportService.submitMultipleReports(reports);
      
      logger.info(`Completed reporting ${reports.length} URLs`);
      return results;
      
    } catch (error) {
      logger.error('Failed to report multiple URLs', Helpers.formatError(error));
      throw error;
    }
  }

  getTargetUrl(targetSite) {
    switch (targetSite) {
      case 'googleSafeBrowsing':
        return this.config.targets.googleSafeBrowsing;
      default:
        throw new Error(`Unsupported target site: ${targetSite}`);
    }
  }

  async getAvailableTargets() {
    return Object.keys(this.config.targets);
  }

  async sendTelegramNotifications(url, result, options) {
    const {
      userId = null,
      username = 'System',
      chatId = null,
      intervalHours = null,
      scheduled = false,
      reportId = null
    } = options;

    try {
      if (!scheduled && chatId) {
        let successMessage = `✅ Successfully reported: ${url}`;
        if (intervalHours !== null) {
          successMessage += `\n\n⏰ Scheduled to repeat every ${intervalHours} hour(s)`;
          successMessage += `\n📌 Use /stopreport ${url} to cancel`;
        }
        
        if (result.screenshotPath) {
          await this.bot.sendPhoto(chatId, result.screenshotPath, { caption: successMessage });
        } else {
          await this.bot.sendMessage(chatId, successMessage);
        }
      }

      // Notify admin users
      const adminIds = await this.db.getAdminUsers();
      console.log('Notifying admins:', adminIds);
      
      for (const adminId of adminIds) {
        // Don't notify the user who triggered the report (unless it's scheduled)
        if (!scheduled && adminId.user_id === userId) {
          continue;
        }
        
        let adminMessage;
        if (scheduled) {
          adminMessage = `🔄 Scheduled Report Executed\n📌 Report ID: ${reportId}\n🔗 URL: ${url}\n✅ Status: Success`;
        } else {
          adminMessage = `📊 Report submitted\n👤 User: ${username} (${userId})\n🔗 URL: ${url}`;
          if (intervalHours) {
            adminMessage += `\n⏰ Interval: ${intervalHours}h`;
          }
        }
        
        try {
          await this.bot.sendMessage(adminId.user_id, adminMessage);
        } catch (err) {
          logger.error(`Failed to notify admin ${adminId.user_id}:`, err);
        }
      }
    } catch (error) {
      logger.error('Error sending Telegram notifications:', Helpers.formatError(error));
      // Don't throw error here to avoid failing the whole report
    }
  }

  async shutdown() {
    try {
      await this.browserService.close();
      this.isInitialized = false;
      logger.info('ReportController shutdown successfully');
    } catch (error) {
      logger.error('Failed to shutdown ReportController', Helpers.formatError(error));
    }
  }

  async setBotAndDatabase(bot, database) {
    this.bot = bot;
    this.db = database;
  }

  async handleTelegramCommand(command, params) {
    try {
      switch (command) {
        case '/report':
          if (!params.url) {
            throw new Error('URL parameter is required');
          }
          return await this.reportUrl(params.url, params.options);
          
        case '/report_multiple':
          if (!params.urls || !Array.isArray(params.urls)) {
            throw new Error('URLs array parameter is required');
          }
          return await this.reportMultipleUrls(params.urls, params.options);
          
        case '/targets':
          return await this.getAvailableTargets();
          
        case '/status':
          return {
            initialized: this.isInitialized,
            timestamp: new Date().toISOString()
          };
          
        default:
          throw new Error(`Unknown command: ${command}`);
      }
    } catch (error) {
      logger.error(`Failed to handle Telegram command: ${command}`, Helpers.formatError(error));
      throw error;
    }
  }
}

module.exports = ReportController;
