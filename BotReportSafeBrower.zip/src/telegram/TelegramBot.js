const TelegramBotAPI = require('node-telegram-bot-api');
const ConfigManager = require('../services/ConfigManager');
const DatabaseManager = require('../services/DatabaseManager');
const SchedulerService = require('../services/SchedulerService');
const logger = require('../utils/logger');
const Helpers = require('../utils/helpers');

class TelegramBot {
  constructor(reportController) {
    this.reportController = reportController;
    this.bot = null;
    this.db = null;
    this.scheduler = null;
    this.schedulerInterval = null;
    this.cleanupInterval = null;
    this.config = null;
    this.isRunning = false;
  }

  async initialize() {
    try {
      await ConfigManager.initialize();
      this.config = await ConfigManager.getStructuredConfig();
      this.db = ConfigManager.getDatabase();
      
      if (!this.config.telegram.botToken) {
        throw new Error('Telegram bot token not configured in database');
      }
      
      await this.initializeAdminUsers();
      const TelegramBotAPI = require('node-telegram-bot-api');
      this.bot = new TelegramBotAPI(this.config.telegram.botToken, { polling: true });
      
      // Set bot and database in ReportController
      this.reportController.setBotAndDatabase(this.bot, this.db);
      
      this.scheduler = new SchedulerService(this.db, this.reportController, this.bot);
      await this.scheduler.initialize();
      logger.info('SchedulerService initialized');
      this.startUserCleanup();
      this.setupHandlers();
      
      logger.info('Telegram bot initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize Telegram bot', Helpers.formatError(error));
      throw error;
    }
  }

  async initializeAdminUsers() {
    const adminUsersStr = await ConfigManager.get('telegram.adminUsers', '');
    const adminUsers = adminUsersStr ? adminUsersStr.split(',').map(id => id.trim()) : [];
    for (const adminId of adminUsers) {
      const user = await this.db.getUser(adminId);
      if (!user) {
        await this.db.addUser(adminId, 'Admin', 'SYSTEM', null, true);
        logger.info(`Initialized admin user: ${adminId}`);
      }
    }
  }

  setupHandlers() {
    if (!this.bot) return;
    this.bot.onText(/\/start/, this.handleStart.bind(this));
    this.bot.onText(/\/help/, this.handleHelp.bind(this));
    this.bot.onText(/\/report\s+(\S+)(?:\s+(\d+(?:\.\d+)?))?/, this.handleReport.bind(this));
    this.bot.onText(/\/stopreport\s+(\S+)/, this.handleStopReport.bind(this));
    this.bot.onText(/\/listreports/, this.handleListReports.bind(this));
    this.bot.onText(/\/status/, this.handleStatus.bind(this));
    this.bot.onText(/\/targets/, this.handleTargets.bind(this));
    this.bot.onText(/\/scheduler/, this.handleSchedulerStatus.bind(this));

    this.bot.onText(/\/adduser\s+(\d+)(?:\s+(\d+(?:\.\d+)?))?/, this.handleAddUser.bind(this));
    this.bot.onText(/\/removeuser\s+(\d+)/, this.handleRemoveUser.bind(this));
    this.bot.onText(/\/listusers/, this.handleListUsers.bind(this));
    
    this.bot.onText(/\/getconfig(?:\s+(.+))?/, this.handleGetConfig.bind(this));
    this.bot.onText(/\/setconfig\s+(\S+)\s+(.+)/, this.handleSetConfig.bind(this));
    this.bot.onText(/\/listconfig/, this.handleListConfig.bind(this));
    
    this.bot.on('polling_error', (error) => {
      logger.error('Telegram polling error', Helpers.formatError(error));
    });
  }

  async handleStart(msg) {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const username = msg.from.username || msg.from.first_name;

    const isAuthorized = await this.db.isUserAuthorized(userId);
    const isAdmin = await this.db.isUserAdmin(userId);
    
    if (!isAuthorized) {
      await this.sendMessage(chatId, '❌ Sorry, you are not authorized to use this bot.\nPlease contact an administrator.');
      return;
    }

    let welcomeMessage = `
Welcome to Bot Report Safe Browser! 🤖

👤 User: ${username}
🔑 Status: ${isAdmin ? 'Admin' : 'User'}

📋 Available commands:
• /help - Show detailed help
• /report <url> [interval_hours] - Report a URL (optionally schedule)
• /stopreport <url> - Stop scheduled reports for a URL
• /listreports - Show your active scheduled reports
• /status - Check bot status
• /targets - List available reporting targets`;

    if (isAdmin) {
      welcomeMessage += `

👨‍💼 Admin commands:
• /adduser, /removeuser, /listusers
• /getconfig, /setconfig, /listconfig`;
    }

    await this.sendMessage(chatId, welcomeMessage);
  }

  async handleHelp(msg) {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const isAuthorized = await this.db.isUserAuthorized(userId);
    const isAdmin = await this.db.isUserAdmin(userId);
    
    if (!isAuthorized) {
      await this.sendMessage(chatId, '❌ Unauthorized access');
      return;
    }

    let helpMessage = `
🤖 Bot Report Safe Browser - Detailed Help

📌 User Commands:

🔸 /report <url> [interval_hours]
   Report a URL to Google Safe Browsing
   • url: The website to report
   • interval_hours: (Optional) Repeat interval (0.1-24 hours)
   Examples:
   • /report https://malicious.com - Single report
   • /report https://phishing.com 0.5 - Report every 30 minutes
   • /report https://scam.com 6 - Report every 6 hours

🔸 /stopreport <url>
   Stop all scheduled reports for a specific URL
   Example: /stopreport https://malicious.com

🔸 /listreports
   View all your active scheduled reports

🔸 /status
   Check if the bot is running

🔸 /targets
   List available reporting platforms`;

    if (isAdmin) {
      helpMessage += `

👨‍💼 Admin Commands:

🔹 /adduser <user_id> [expiry_days]
   Grant access to a new user
   • user_id: Telegram user ID
   • expiry_days: (Optional) Access duration in days
   Examples:
   • /adduser 123456789 - Permanent access
   • /adduser 123456789 30 - 30-day access

🔹 /removeuser <user_id>
   Revoke access from a user
   Example: /removeuser 123456789

🔹 /listusers
   Display all authorized users and their expiry times

🔹 /getconfig [key]
   Get configuration value
   Example: /getconfig browser.headless

🔹 /setconfig <key> <value>
   Update configuration value
   Example: /setconfig browser.maxConcurrency 3

🔹 /listconfig
   Show all configuration settings`;
    }

    helpMessage += `

ℹ️ Notes:
• Screenshots are automatically captured for evidence
• Reports are submitted to Google Safe Browsing
• Scheduled reports survive bot restarts
• Expired users are automatically cleaned up`;

    await this.sendMessage(chatId, helpMessage);
  }

  async handleReport(msg, match) {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const username = msg.from.username || msg.from.first_name;
    const url = match[1];
    const intervalHours = match[2] ? parseFloat(match[2]) : null;

    const isAuthorized = await this.db.isUserAuthorized(userId);
    if (!isAuthorized) {
      await this.sendMessage(chatId, '❌ Your access has expired or been revoked.');
      return;
    }

    if (!Helpers.isValidUrl(url)) {
      await this.sendMessage(chatId, '❌ Invalid URL format. Please provide a valid URL.');
      return;
    }

    if (intervalHours !== null) {
      if (intervalHours < 0.1 || intervalHours > 24) {
        await this.sendMessage(chatId, '❌ Interval must be between 0.1 and 24 hours.');
        return;
      }
    }

    try {
      await this.sendMessage(chatId, `🔄 Processing report for: ${url}`);
       
      const result = await this.reportController.reportUrl(url, {
        targetSite: 'googleSafeBrowsing',
        takeScreenshot: true,
        userId,
        username,
        chatId,
        intervalHours
      });
      
      await this.db.addReportHistory(
        url, 
        userId, 
        result.success, 
        result.screenshotPath,
        result.error || null
      );

      if (result.success) {
        if (intervalHours !== null) {
          const reportId = await this.scheduler.addScheduledReport(url, userId, intervalHours);
          await this.db.logAction('SCHEDULE_REPORT', userId, null, 
            `Scheduled report for ${url} every ${intervalHours} hours`);
        }
      } else {
        await this.sendMessage(chatId, `❌ Failed to report: ${url}\nError: ${result.error || 'Unknown error'}`);
      }

    } catch (error) {
      logger.error('Error handling report command', Helpers.formatError(error));
      await this.sendMessage(chatId, `❌ Error processing report: ${error.message}`);
    }
  }

  async handleStopReport(msg, match) {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const url = match[1];

    const isAuthorized = await this.db.isUserAuthorized(userId);
    if (!isAuthorized) {
      await this.sendMessage(chatId, '❌ Unauthorized access');
      return;
    }

    try {
      const stopped = await this.scheduler.stopScheduledReportByUrl(url, userId);
      
      if (stopped) {
        await this.sendMessage(chatId, `✅ Stopped scheduled reports for: ${url}`);
        await this.db.logAction('STOP_REPORT', userId, null, `Stopped scheduled report for ${url}`);
      } else {
        await this.sendMessage(chatId, `❌ No active scheduled reports found for: ${url}`);
      }
    } catch (error) {
      logger.error('Error stopping report', Helpers.formatError(error));
      await this.sendMessage(chatId, '❌ Error stopping report');
    }
  }

  async handleListReports(msg) {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const isAuthorized = await this.db.isUserAuthorized(userId);
    if (!isAuthorized) {
      await this.sendMessage(chatId, '❌ Unauthorized access');
      return;
    }

    try {
      const reports = await this.scheduler.getScheduledReports(userId);
      
      if (reports.length === 0) {
        await this.sendMessage(chatId, '📋 You have no active scheduled reports.');
        return;
      }

      let message = '📋 Your Active Scheduled Reports:\n\n';
      for (const report of reports) {
        const lastRun = report.last_run ? new Date(report.last_run) : null;
        const createdAt = new Date(report.created_at);
        
        message += `🔗 URL: ${report.url}\n`;
        message += `⏰ Interval: ${report.interval_hours} hour(s)\n`;
        message += `📊 Run count: ${report.run_count || 0}\n`;
        message += `📅 Last run: ${lastRun ? lastRun.toLocaleString() : 'Not yet run'}\n`;
        message += `🚀 Created: ${createdAt.toLocaleString()}\n`;
        message += `─────────────────\n`;
      }

      await this.sendMessage(chatId, message);
    } catch (error) {
      logger.error('Error listing reports', Helpers.formatError(error));
      await this.sendMessage(chatId, '❌ Error fetching reports');
    }
  }

  async handleAddUser(msg, match) {
    const chatId = msg.chat.id;
    const adminId = msg.from.id.toString();
    const targetUserId = match[1];
    const expiryDays = match[2] ? parseFloat(match[2]) : null;
    const isAdmin = await this.db.isUserAdmin(adminId);
    if (!isAdmin) {
      await this.sendMessage(chatId, '❌ This command is restricted to administrators only.');
      return;
    }

    try {
      const result = await this.db.addUser(targetUserId, `User_${targetUserId}`, adminId, expiryDays, false);
      
      let message = `✅ User ${targetUserId} has been granted access`;
      if (expiryDays) {
        const expiryDate = new Date(result.expiresAt);
        message += ` until ${expiryDate.toLocaleDateString()}`;
      } else {
        message += ` (permanent)`;
      }
      
      await this.sendMessage(chatId, message);
      try {
        const welcomeMsg = `🎉 You have been granted access to Bot Report Safe Browser!\n${expiryDays ? `⏰ Access valid for ${expiryDays} days` : '✨ Permanent access granted'}\n\nType /start to begin.`;
        await this.sendMessage(targetUserId, welcomeMsg);
      } catch (e) {
        // User might not have started the bot yet
      }
      
    } catch (error) {
      logger.error('Error adding user', Helpers.formatError(error));
      await this.sendMessage(chatId, `❌ Error adding user: ${error.message}`);
    }
  }

  async handleRemoveUser(msg, match) {
    const chatId = msg.chat.id;
    const adminId = msg.from.id.toString();
    const targetUserId = match[1];

    const isAdmin = await this.db.isUserAdmin(adminId);
    if (!isAdmin) {
      await this.sendMessage(chatId, '❌ This command is restricted to administrators only.');
      return;
    }

    if (targetUserId === adminId) {
      await this.sendMessage(chatId, '❌ You cannot remove yourself.');
      return;
    }

    try {
      await this.db.removeUser(targetUserId, adminId);
      await this.sendMessage(chatId, `✅ User ${targetUserId} has been removed.`);
      
      try {
        await this.sendMessage(targetUserId, '⚠️ Your access to Bot Report Safe Browser has been revoked.');
      } catch (e) {
        // User might have blocked the bot
      }
      
    } catch (error) {
      logger.error('Error removing user', Helpers.formatError(error));
      await this.sendMessage(chatId, `❌ Error removing user: ${error.message}`);
    }
  }

  async handleListUsers(msg) {
    const chatId = msg.chat.id;
    const adminId = msg.from.id.toString();

    const isAdmin = await this.db.isUserAdmin(adminId);
    if (!isAdmin) {
      await this.sendMessage(chatId, '❌ This command is restricted to administrators only.');
      return;
    }

    try {
      const users = await this.db.listUsers();
      
      if (users.length === 0) {
        await this.sendMessage(chatId, '📋 No authorized users found.');
        return;
      }

      let message = '👥 Authorized Users:\n\n';
      
      const admins = users.filter(u => u.is_admin);
      const normalUsers = users.filter(u => !u.is_admin);
      
      if (admins.length > 0) {
        message += '👨‍💼 Administrators:\n';
        for (const admin of admins) {
          message += `• ${admin.user_id} (${admin.username})\n`;
        }
        message += '\n';
      }
      
      if (normalUsers.length > 0) {
        message += '👤 Users:\n';
        for (const user of normalUsers) {
          message += `• ${user.user_id} (${user.username})`;
          if (user.expires_at) {
            const expiryDate = new Date(user.expires_at);
            const daysLeft = Math.ceil((expiryDate - new Date()) / (1000 * 60 * 60 * 24));
            message += ` - Expires: ${expiryDate.toLocaleDateString()} (${daysLeft} days)`;
          } else {
            message += ` - Permanent`;
          }
          message += '\n';
        }
      }
      
      message += `\n📊 Total: ${users.length} users`;
      
      await this.sendMessage(chatId, message);
    } catch (error) {
      logger.error('Error listing users', Helpers.formatError(error));
      await this.sendMessage(chatId, '❌ Error fetching user list');
    }
  }

  async handleStatus(msg) {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const isAuthorized = await this.db.isUserAuthorized(userId);
    if (!isAuthorized) {
      await this.sendMessage(chatId, '❌ Unauthorized access');
      return;
    }

    try {
      const status = await this.reportController.handleTelegramCommand('/status', {});
      const scheduledReports = await this.db.getScheduledReports();
      const users = await this.db.listUsers();
      
      const statusMessage = `
🤖 Bot Status
━━━━━━━━━━━━━━━━
✅ Bot: Active
✅ Report Service: ${status.initialized ? 'Ready' : 'Not ready'}
📊 Active Users: ${users.length}
⏰ Scheduled Reports: ${scheduledReports.length}
🕐 Server Time: ${new Date().toLocaleString()}
      `;
      await this.sendMessage(chatId, statusMessage);
    } catch (error) {
      await this.sendMessage(chatId, '❌ Error checking status');
    }
  }

  async handleTargets(msg) {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const isAuthorized = await this.db.isUserAuthorized(userId);
    if (!isAuthorized) {
      await this.sendMessage(chatId, '❌ Unauthorized access');
      return;
    }

    try {
      const targets = await this.reportController.getAvailableTargets();
      const targetsList = targets.map(target => `• ${target}`).join('\n');
      await this.sendMessage(chatId, `📋 Available reporting targets:\n${targetsList}`);
    } catch (error) {
      await this.sendMessage(chatId, '❌ Error getting targets');
    }
  }

  async handleSchedulerStatus(msg) {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const isAdmin = await this.db.isUserAdmin(userId);
    if (!isAdmin) {
      await this.sendMessage(chatId, '❌ This command is restricted to administrators only.');
      return;
    }

    try {
      const status = this.scheduler.getStatus();
      const allReports = await this.scheduler.getScheduledReports();
      
      let message = '⚙️ Scheduler Status\n\n';
      message += `📊 Status: ${status.isRunning ? '✅ Running' : '❌ Stopped'}\n`;
      message += `📝 Active Jobs: ${status.activeJobs}\n`;
      message += `📋 Total Reports: ${allReports.length}\n\n`;
      
      if (allReports.length > 0) {
        message += '📌 Recent Reports:\n';
        const recentReports = allReports.slice(0, 5);
        for (const report of recentReports) {
          const lastRun = report.last_run ? new Date(report.last_run) : null;
          message += `\n🔗 ${report.url}\n`;
          message += `   👤 User: ${report.user_id}\n`;
          message += `   ⏰ Every ${report.interval_hours}h\n`;
          message += `   📅 Last: ${lastRun ? lastRun.toLocaleString() : 'Never'}\n`;
          message += `   📊 Runs: ${report.run_count || 0}\n`;
        }
        
        if (allReports.length > 5) {
          message += `\n... and ${allReports.length - 5} more reports`;
        }
      }
      
      await this.sendMessage(chatId, message);
    } catch (error) {
      logger.error('Error getting scheduler status', Helpers.formatError(error));
      await this.sendMessage(chatId, '❌ Error getting scheduler status');
    }
  }

  startUserCleanup() {
    setInterval(async () => {
      try {
        const cleaned = await this.db.cleanupExpiredUsers();
        if (cleaned > 0) {
          logger.info(`Cleaned up ${cleaned} expired users`);
        }
      } catch (error) {
        logger.error('Error in user cleanup', Helpers.formatError(error));
      }
    }, 60 * 60 * 1000); // 1 hour
  }

  startScheduledReportsProcessor() {
    this.schedulerInterval = setInterval(async () => {
      try {
        const reports = await this.db.getReportsToRun();
        
        for (const report of reports) {
          try {
            logger.info(`Running scheduled report: ${report.url} for user ${report.user_id}`);
            
            const result = await this.reportController.reportUrl(report.url, {
              targetSite: 'googleSafeBrowsing',
              takeScreenshot: true
            });
            const nextRun = new Date(Date.now() + report.interval_hours * 60 * 60 * 1000);
            await this.db.updateScheduledReport(report.id, new Date().toISOString(), nextRun.toISOString());
            
            await this.db.addReportHistory(
              report.url,
              report.user_id,
              result.success,
              result.screenshotPath,
              result.error || null
            );
            
            if (!result.success) {
              await this.sendMessage(report.user_id, 
                `⚠️ Scheduled report failed for ${report.url}\nError: ${result.error || 'Unknown error'}`);
            }
            
          } catch (error) {
            logger.error(`Failed to run scheduled report ${report.id}`, Helpers.formatError(error));
            
            try {
              await this.sendMessage(report.user_id, 
                `❌ Scheduled report error for ${report.url}\nThe report will retry at the next interval.`);
            } catch (e) {
              // User might have blocked the bot
            }
          }
        }
      } catch (error) {
        logger.error('Error in scheduled reports processor', Helpers.formatError(error));
      }
    }, 60 * 1000); // Check every minute
  }

  async sendMessage(chatId, message, options = {}) {
    if (!this.bot) return;

    try {
      await this.bot.sendMessage(chatId, message, { parse_mode: undefined, ...options });
    } catch (error) {
      logger.error('Failed to send Telegram message', Helpers.formatError(error));
    }
  }

  async stop() {
    if (this.scheduler) {
      await this.scheduler.shutdown();
    }
    
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }
    
    await this.db.close();
    
    if (this.bot) {
      try {
        await this.bot.stopPolling();
        logger.info('Telegram bot stopped');
      } catch (error) {
        logger.error('Error stopping Telegram bot', Helpers.formatError(error));
      }
    }
  }

  async start() {
    try {
      await this.initialize();
      logger.info('Telegram bot started successfully');
    } catch (error) {
      logger.error('Failed to start Telegram bot', Helpers.formatError(error));
      throw error;
    }
  }

  async handleGetConfig(msg, match) {
    const chatId = msg.chat.id;
    const adminId = msg.from.id.toString();
    const key = match ? match[1] : null;

    const isAdmin = await this.db.isUserAdmin(adminId);
    if (!isAdmin) {
      await this.sendMessage(chatId, '❌ This command is restricted to administrators only.');
      return;
    }

    try {
      if (key) {
        const value = await ConfigManager.get(key);
        if (value !== null) {
          await this.sendMessage(chatId, `⚙️ Configuration:\n\n📝 ${key} = ${value}`);
        } else {
          await this.sendMessage(chatId, `❌ Configuration key "${key}" not found.`);
        }
      } else {
        await this.sendMessage(chatId, '📋 Usage: /getconfig <key>\n\nExample: /getconfig telegram.botToken');
      }
    } catch (error) {
      logger.error('Error getting config', Helpers.formatError(error));
      await this.sendMessage(chatId, `❌ Error: ${error.message}`);
    }
  }

  async handleSetConfig(msg, match) {
    const chatId = msg.chat.id;
    const adminId = msg.from.id.toString();
    const key = match[1];
    const value = match[2];

    const isAdmin = await this.db.isUserAdmin(adminId);
    if (!isAdmin) {
      await this.sendMessage(chatId, '❌ This command is restricted to administrators only.');
      return;
    }

    try {
      let type = 'string';
      let parsedValue = value;
      
      if (value === 'true' || value === 'false') {
        type = 'boolean';
        parsedValue = value === 'true';
      } else if (!isNaN(value)) {
        if (value.includes('.')) {
          type = 'float';
          parsedValue = parseFloat(value);
        } else {
          type = 'integer';
          parsedValue = parseInt(value);
        }
      }

      await ConfigManager.set(key, parsedValue, type);
      
      await this.sendMessage(chatId, `✅ Configuration updated:\n\n📝 ${key} = ${parsedValue}`);
      
      await this.db.logAction(adminId, 'set_config', {
        key: key,
        value: parsedValue,
        type: type
      });
      
      if (key === 'telegram.botToken') {
        await this.sendMessage(chatId, '⚠️ Bot token changed. Restart required for changes to take effect.');
      }
      
    } catch (error) {
      logger.error('Error setting config', Helpers.formatError(error));
      await this.sendMessage(chatId, `❌ Error: ${error.message}`);
    }
  }

  async handleListConfig(msg) {
    const chatId = msg.chat.id;
    const adminId = msg.from.id.toString();

    const isAdmin = await this.db.isUserAdmin(adminId);
    if (!isAdmin) {
      await this.sendMessage(chatId, '❌ This command is restricted to administrators only.');
      return;
    }

    try {
      const allConfig = await ConfigManager.getAll();
      
      let message = '⚙️ All Configuration:\n\n';
      
      const categories = {};
      for (const [key, config] of Object.entries(allConfig)) {
        const category = key.split('.')[0];
        if (!categories[category]) {
          categories[category] = [];
        }
        categories[category].push({ key, ...config });
      }
      
      for (const [category, configs] of Object.entries(categories)) {
        message += `📁 ${category.toUpperCase()}\n`;
        for (const config of configs) {
          let displayValue = config.value;
          if (config.key.includes('token') || config.key.includes('Token')) {
            displayValue = displayValue ? '***' : '(not set)';
          }
          message += `  • ${config.key}: ${displayValue}\n`;
        }
        message += '\n';
      }
      
      message += '💡 Use /setconfig <key> <value> to modify';
      
      await this.sendMessage(chatId, message);
      
    } catch (error) {
      logger.error('Error listing config', Helpers.formatError(error));
      await this.sendMessage(chatId, `❌ Error: ${error.message}`);
    }
  }
}

module.exports = TelegramBot;
