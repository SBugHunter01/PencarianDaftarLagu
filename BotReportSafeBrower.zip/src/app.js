const ReportController = require('./controllers/ReportController');
const logger = require('./utils/logger');
const TelegramBot = require('./telegram/TelegramBot');
const ConfigManager = require('./services/ConfigManager');

class App {
  constructor() {
    this.reportController = new ReportController();
    this.telegramBot = null;
    this.isRunning = false;
  }

  async start() {
    try {
      logger.info('Starting Bot Report Safe Browser application...');
      
      await ConfigManager.initialize();
      logger.info('Configuration loaded from database');
      
      await this.reportController.initialize();
      this.isRunning = true;
      
      const isBotConfigured = await ConfigManager.isBotConfigured();
      if (isBotConfigured) {
        this.telegramBot = new TelegramBot(this.reportController);
        await this.telegramBot.start();
        logger.info('Telegram bot started successfully');
      } else {
        logger.warn('Telegram bot token not configured in database - bot will not start');
        logger.info('Use /setconfig telegram.botToken <your_token> to configure');
      }
      
      logger.info('Application started successfully');
      
    } catch (error) {
      console.log(error);
      logger.error('Failed to start application', error);
      process.exit(1);
    }
  }

  async runExample() {
    try {
      logger.info('Running example report...');
      
      const result = await this.reportController.reportSingleUrl(
        'https://example.com',
        'This is a test report'
      );
      
      logger.info('Example report completed', { result });
      
    } catch (error) {
      logger.error('Example failed', error);
    }
  }

  async handleTelegramUpdate(update) {
    logger.info('Received Telegram update', { update });
    return await this.reportController.handleTelegramCommand(update);
  }

  async shutdown() {
    logger.info('Shutting down application...');
    
    if (this.isRunning) {
      if (this.telegramBot) {
        await this.telegramBot.stop();
      }
      await this.reportController.cleanup();
      this.isRunning = false;
    }
    
    logger.info('Application shutdown complete');
  }
}

const app = new App();

process.on('SIGINT', async () => {
  logger.info('Received SIGINT, shutting down gracefully...');
  if (global.app) {
    await global.app.shutdown();
  }
  process.exit(0);
});

process.on('SIGTERM', async () => {
  logger.info('Received SIGTERM, shutting down gracefully...');
  if (global.app) {
    await global.app.shutdown();
  }
  process.exit(0);
});

async function main() {
  global.app = new App();
  await global.app.start();
}

if (require.main === module) {
  main().catch(error => {
    logger.error('Unhandled error in main', error);
    process.exit(1);
  });
}

module.exports = App;
